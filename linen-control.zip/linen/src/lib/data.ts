import { redirect } from "next/navigation";
import { sb } from "./supabase/server";
export type Role = "student" | "laundry" | "director";
export const STATUS = {
  none: { label: "Не сдано", icon: "❌", cls: "bg-red-100 text-red-700" },
  pending: { label: "Ожидает подтверждения", icon: "🟡", cls: "bg-yellow-100 text-yellow-800" },
  confirmed: { label: "Подтверждено", icon: "🟢", cls: "bg-green-100 text-green-700" },
} as const;
export const st = (s?: string | null) => STATUS[(s as "pending" | "confirmed") ?? "none"] ?? STATUS.none;
export const fmt = (d?: string | null) => (d ? new Date(d).toLocaleString("ru-RU", { dateStyle: "medium", timeStyle: "short" }) : "—");
export async function me(roles: Role[]) {
  const s = await sb();
  const { data: { user } } = await s.auth.getUser();
  if (!user) redirect("/login");
  const { data: p } = await s.from("profiles").select("*, rooms(id, number, floors(number))").eq("id", user.id).single();
  if (!p || !roles.includes(p.role)) redirect("/");
  return { s, user, p };
}
export async function currentPeriod(s: Awaited<ReturnType<typeof sb>>, id?: string) {
  const { data: all } = await s.from("periods").select("*").order("start_date", { ascending: false });
  const today = new Date().toISOString().slice(0, 10);
  const cur = (id && all?.find((x) => String(x.id) === id)) || all?.find((x) => x.start_date <= today && x.end_date >= today) || all?.[0] || null;
  return { all: all ?? [], cur };
}
export const daysLeft = (end: string) => Math.ceil((new Date(end + "T23:59:59").getTime() - Date.now()) / 86400000);
