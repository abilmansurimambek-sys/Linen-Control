import Link from "next/link";
import { me, currentPeriod, st } from "@/lib/data";
import { periodData } from "@/lib/stats";
export default async function Floor({ params, searchParams }: { params: Promise<{ n: string }>; searchParams: Promise<{ period?: string }> }) {
  const { n } = await params; const { period } = await searchParams;
  const { s } = await me(["director"]);
  const { cur } = await currentPeriod(s, period);
  const rows = (cur ? await periodData(s, cur.id) : []).filter((r) => String(r.floor) === n).sort((a, b) => a.room.localeCompare(b.room));
  return (
    <main className="mx-auto max-w-3xl space-y-3 p-6">
      <Link href="/admin" className="text-sm underline">← Назад</Link><h1 className="text-2xl font-bold">{n} этаж</h1>
      {rows.map((r) => <Link key={r.id} href={`/admin/student/${r.id}`} className="flex justify-between rounded-2xl bg-white p-4 shadow-sm">
        <span>{r.room} · {r.full_name}</span><span>{st(r.sub?.status).icon} {st(r.sub?.status).label}</span></Link>)}
    </main>
  );
}
