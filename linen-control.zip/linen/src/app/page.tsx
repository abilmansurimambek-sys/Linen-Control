import { redirect } from "next/navigation";
import { me } from "@/lib/data";
export default async function Home() {
  const { p } = await me(["student", "laundry", "director"]);
  redirect(p.role === "director" ? "/admin" : p.role === "laundry" ? "/laundry" : "/student");
}
