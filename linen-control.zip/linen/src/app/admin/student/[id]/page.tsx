import Link from "next/link";
import { me, currentPeriod, st, fmt } from "@/lib/data";
export default async function Stu({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { s } = await me(["director"]);
  const { all, cur } = await currentPeriod(s);
  const { data: p }: any = await s.from("profiles").select("full_name, rooms(number, floors(number))").eq("id", id).single();
  const { data: subs }: any = await s.from("submissions").select("*, laundry_confirmations(*, profiles:confirmed_by(full_name))").eq("student_id", id);
  const mine = subs?.find((x: any) => x.period_id === cur?.id);
  const c = mine?.laundry_confirmations;
  const url = c ? (await s.storage.from("linen-photos").createSignedUrl(c.photo_path, 3600)).data?.signedUrl : null;
  const x = st(mine?.status);
  return (
    <main className="mx-auto max-w-xl space-y-4 p-6">
      <Link href="/admin" className="text-sm underline">← Назад</Link>
      <h1 className="text-2xl font-bold">{p?.full_name}</h1><p>Комната {p?.rooms?.number} · {p?.rooms?.floors?.number} этаж</p>
      <div className="space-y-2 rounded-2xl bg-white p-5"><p className="text-sm text-gray-500">{cur?.name}: {cur?.start_date} — {cur?.end_date}</p>
        <div className={`rounded-xl p-4 text-xl font-bold ${x.cls}`}>{x.icon} {x.label}</div>
        <p>Дата сдачи: {fmt(mine?.submitted_at)}</p><p>Дата подтверждения: {fmt(c?.received_at)}</p>
        <p>Комплектов: {c?.sets_count ?? "—"}</p><p>Ответственный: {c?.profiles?.full_name ?? "—"}</p>
        {url && <a href={url} target="_blank"><img src={url} alt="Фотоотчёт" className="mt-2 w-full rounded-xl" /></a>}</div>
      <div className="rounded-2xl bg-white p-5"><h2 className="mb-2 font-semibold">История</h2>
        {all.map((a) => <div key={a.id} className="flex justify-between border-b py-2 last:border-0"><span>{a.start_date} — {a.end_date}</span><span>{st(subs?.find((y: any) => y.period_id === a.id)?.status).icon}</span></div>)}</div>
    </main>
  );
}
