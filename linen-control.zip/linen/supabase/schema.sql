-- Run whole file in Supabase SQL Editor.
create table floors (id serial primary key, number int unique not null);
create table rooms (id serial primary key, floor_id int not null references floors(id), number text unique not null);
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('student','laundry','director')),
  room_id int references rooms(id),
  created_at timestamptz default now(), updated_at timestamptz default now());
create table periods (
  id serial primary key, name text not null, start_date date not null, end_date date not null check (end_date>=start_date),
  created_at timestamptz default now());
create table submissions (
  id serial primary key, period_id int not null references periods(id), student_id uuid not null references profiles(id),
  status text not null default 'pending' check (status in ('pending','confirmed')),
  submitted_at timestamptz default now(), created_at timestamptz default now(), updated_at timestamptz default now(),
  unique (period_id, student_id));
create table laundry_confirmations (
  id serial primary key, submission_id int unique not null references submissions(id) on delete cascade,
  confirmed_by uuid not null references profiles(id), sets_count int not null check (sets_count>0),
  photo_path text not null, received_at timestamptz not null default now(), created_at timestamptz default now());
create table notifications (
  id serial primary key, user_id uuid not null references profiles(id) on delete cascade,
  message text not null, is_read boolean default false, created_at timestamptz default now());

create function my_role() returns text language sql security definer stable set search_path=public as
$$ select role from profiles where id = auth.uid() $$;

create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name','')); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table floors enable row level security; alter table rooms enable row level security;
alter table profiles enable row level security; alter table periods enable row level security;
alter table submissions enable row level security; alter table laundry_confirmations enable row level security;
alter table notifications enable row level security;

create policy floors_r on floors for select to authenticated using (true);
create policy rooms_r on rooms for select to authenticated using (true);
create policy periods_r on periods for select to authenticated using (true);
create policy periods_w on periods for insert to authenticated with check (my_role()='director');
create policy profiles_r on profiles for select to authenticated using (id=auth.uid() or my_role() in ('laundry','director'));
create policy sub_r on submissions for select to authenticated using (student_id=auth.uid() or my_role() in ('laundry','director'));
create policy conf_r on laundry_confirmations for select to authenticated using (
  my_role() in ('laundry','director') or exists (select 1 from submissions s where s.id=submission_id and s.student_id=auth.uid()));
create policy notif_r on notifications for select to authenticated using (user_id=auth.uid());
-- No insert/update/delete policies on profiles, submissions, confirmations, notifications:
-- all writes go through the security-definer functions below.

create function set_my_room(p_room int) returns void language sql security definer set search_path=public as
$$ update profiles set room_id=p_room, updated_at=now() where id=auth.uid() $$;

create function student_mark_submitted(p_period int) returns void language plpgsql security definer set search_path=public as $$
begin
  if my_role() <> 'student' then raise exception 'students only'; end if;
  insert into submissions (period_id, student_id, status) values (p_period, auth.uid(), 'pending')
    on conflict (period_id, student_id) do nothing;
  insert into notifications (user_id, message) values (auth.uid(), 'Ваша сдача ожидает подтверждения.');
end $$;

create function confirm_submission(p_student uuid, p_period int, p_sets int, p_photo text, p_received timestamptz)
returns void language plpgsql security definer set search_path=public as $$
declare sid int;
begin
  if my_role() not in ('laundry','director') then raise exception 'not allowed'; end if;
  if p_photo is null or p_photo = '' or p_sets is null or p_sets < 1 then raise exception 'photo and sets required'; end if;
  insert into submissions (period_id, student_id, status) values (p_period, p_student, 'confirmed')
    on conflict (period_id, student_id) do update set status='confirmed', updated_at=now()
    returning id into sid;
  insert into laundry_confirmations (submission_id, confirmed_by, sets_count, photo_path, received_at)
    values (sid, auth.uid(), p_sets, p_photo, coalesce(p_received, now()))
    on conflict (submission_id) do update set confirmed_by=auth.uid(), sets_count=p_sets, photo_path=p_photo, received_at=coalesce(p_received, now());
  insert into notifications (user_id, message) values (p_student, 'Сдача белья подтверждена.');
end $$;

revoke all on function set_my_room, student_mark_submitted, confirm_submission from public, anon;
grant execute on function set_my_room, student_mark_submitted, confirm_submission to authenticated;

insert into storage.buckets (id, name, public) values ('linen-photos','linen-photos',false) on conflict do nothing;
create policy photos_w on storage.objects for insert to authenticated with check (bucket_id='linen-photos' and my_role() in ('laundry','director'));
create policy photos_r on storage.objects for select to authenticated using (bucket_id='linen-photos' and my_role() in ('laundry','director'));

insert into floors (number) select g from generate_series(1,5) g;
insert into rooms (floor_id, number) select f.id, (f.number*100+r)::text from floors f, generate_series(1,10) r;
insert into periods (name, start_date, end_date) values ('Период №1', current_date, current_date + 13);
