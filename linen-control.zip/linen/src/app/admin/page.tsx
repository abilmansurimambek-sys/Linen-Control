import Link from "next/link";
import { me, currentPeriod } from "@/lib/data";
import { periodData, pct } from "@/lib/stats";
import { createPeriod, signOut } from "../actions";
export default async function Admin({ searchParams }: { searchParams: Promise<{ period?: string }> }) {
  const { period } = await searchParams;
  const { s } = await me(["director"]);
  const { all, cur } = await currentPeriod(s, period);
  const rows = cur ? await periodData(s, cur.id) : [];
  const ok = rows.filter((r) => r.sub?.status === "confirmed").length, wait = rows.filter((r) => r.sub?.status === "pending").length;
  const floors = [...new Set(rows.map((r) => r.floor))].sort();
  const card = (t: string, v: any) => <div className="rounded-2xl bg-white p-5 shadow-sm"><p className="text-sm text-gray-500">{t}</p><p className="text-3xl font-bold">{v}</p></div>;
  return (
    <main className="mx-auto max-w-5xl space-y-6 p-6">
      <header className="flex items-center justify-between"><h1 className="text-2xl font-bold">Панель директора</h1>
        <div className="flex gap-4"><Link href="/laundry" className="text-sm underline">Приём белья</Link><form action={signOut}><button className="text-sm text-gray-500 underline">Выйти</button></form></div></header>
      <nav className="flex flex-wrap gap-2">{all.map((x) => <Link key={x.id} href={`/admin?period=${x.id}`} className={`rounded-full border px-4 py-1 text-sm ${x.id === cur?.id ? "bg-black text-white" : "bg-white"}`}>{x.start_date} — {x.end_date}</Link>)}</nav>
      {cur && <>
        <div className="grid gap-4 sm:grid-cols-4">{card("Студентов", rows.length)}{card("Подтверждено", ok)}{card("Ожидает", wait)}{card("Не сдали", rows.length - ok - wait)}</div>
        <div className="rounded-2xl bg-white p-5 shadow-sm"><p>Выполнение <b className="text-2xl">{pct(rows)}%</b></p></div>
        <section className="space-y-2"><h2 className="font-semibold">Этажи</h2>
          {floors.map((f) => { const fr = rows.filter((r) => r.floor === f); return (
            <Link key={f} href={`/admin/floor/${f}?period=${cur.id}`} className="flex items-center gap-4 rounded-2xl bg-white p-4 shadow-sm">
              <span className="w-20">{f} этаж</span><div className="h-3 flex-1 rounded bg-gray-200"><div className="h-3 rounded bg-green-500" style={{ width: `${pct(fr)}%` }} /></div><b className="w-14 text-right">{pct(fr)}%</b></Link>); })}</section></>}
      <form action={createPeriod} className="flex flex-wrap gap-2 rounded-2xl bg-white p-4"><input name="name" placeholder="Название периода" required className="rounded-xl border p-2" />
        <input name="start" type="date" required className="rounded-xl border p-2" /><input name="end" type="date" required className="rounded-xl border p-2" /><button className="rounded-xl bg-black px-4 text-white">Создать период</button></form>
    </main>
  );
}
