import { me, currentPeriod, st, fmt, daysLeft } from "@/lib/data";
import { markSubmitted, setRoom, signOut } from "../actions";
export default async function Student() {
  const { s, user, p } = await me(["student"]);
  const { all, cur } = await currentPeriod(s);
  const { data: subs } = await s.from("submissions").select("*, laundry_confirmations(sets_count, received_at)").eq("student_id", user.id);
  const { data: notes } = await s.from("notifications").select("*").order("created_at", { ascending: false }).limit(5);
  const { data: rooms } = p.room_id ? { data: null } : await s.from("rooms").select("id, number").order("number");
  const mine: any = subs?.find((x) => x.period_id === cur?.id);
  const status = st(mine?.status);
  const left = cur ? daysLeft(cur.end_date) : null;
  const conf = mine?.laundry_confirmations;
  return (
    <main className="mx-auto max-w-md space-y-4 p-4">
      <header className="flex justify-between"><div><h1 className="text-xl font-bold">{p.full_name}</h1>
        <p className="text-gray-500">{p.rooms ? `Комната ${p.rooms.number} · ${p.rooms.floors.number} этаж` : "Комната не выбрана"}</p></div>
        <form action={signOut}><button className="text-sm text-gray-500 underline">Выйти</button></form></header>
      {!p.room_id && (
        <form action={setRoom} className="flex gap-2 rounded-2xl bg-white p-4">
          <select name="room" required className="flex-1 rounded-xl border p-3">{rooms?.map((r: any) => <option key={r.id} value={r.id}>{r.number}</option>)}</select>
          <button className="rounded-xl bg-black px-4 text-white">Сохранить</button></form>)}
      {cur && left !== null && left >= 0 && left <= 2 && !mine && <div className="rounded-2xl bg-orange-100 p-4">До окончания периода сдачи белья осталось {left} дн.</div>}
      {cur ? (
        <section className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-gray-500">{cur.name}: {cur.start_date} — {cur.end_date}</p>
          <div className={`my-4 rounded-2xl p-6 text-center text-2xl font-bold ${status.cls}`}>{status.icon} {status.label}</div>
          {mine && <p className="text-sm text-gray-600">Отмечено: {fmt(mine.submitted_at)}{conf && ` · Комплектов: ${conf.sets_count} · Принято: ${fmt(conf.received_at)}`}</p>}
          {!mine && p.room_id && <form action={markSubmitted}><input type="hidden" name="period" value={cur.id} />
            <button className="mt-2 w-full rounded-2xl bg-black py-4 text-lg font-semibold text-white">Я сдал бельё</button></form>}
        </section>) : <p>Нет активного периода.</p>}
      <section className="rounded-2xl bg-white p-5"><h2 className="mb-2 font-semibold">История</h2>
        {all.map((x) => <div key={x.id} className="flex justify-between border-b py-2 last:border-0"><span>{x.start_date} — {x.end_date}</span>
          <span>{st(subs?.find((y) => y.period_id === x.id)?.status).icon}</span></div>)}</section>
      {!!notes?.length && <section className="rounded-2xl bg-white p-5"><h2 className="mb-2 font-semibold">Уведомления</h2>
        {notes.map((n) => <p key={n.id} className="py-1 text-sm">{n.message} <span className="text-gray-400">{fmt(n.created_at)}</span></p>)}</section>}
    </main>
  );
}
