# Контроль сдачи белья (жатақхана) — MVP
Next.js 15 + TypeScript + Tailwind + Supabase (Auth, Postgres RLS, Storage).

## Supabase
1. supabase.com → New project. Authentication → Providers → Email: для теста отключите «Confirm email».
2. SQL Editor → вставьте и выполните `supabase/schema.sql` (таблицы, RLS, функции, приватный bucket `linen-photos`, 5 этажей × 10 комнат, первый период).
3. Project Settings → API: скопируйте Project URL и anon public key.

## Локально
```
cp .env.example .env.local   # вставьте URL и anon key
npm install && npm run dev   # http://localhost:3000
```

## Первый Director / Laundry
Зарегистрируйтесь через сайт (все новые аккаунты — student), затем в SQL Editor:
```
update profiles set role='director' where id=(select id from auth.users where email='you@mail.com');
update profiles set role='laundry'  where id=(select id from auth.users where email='laundry@mail.com');
```

## GitHub → Vercel
```
git init && git add . && git commit -m "init"
git branch -M main && git remote add origin https://github.com/USER/REPO.git && git push -u origin main
```
Vercel → Add New → Project → выберите репозиторий → Environment Variables: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` → Deploy.
(Supabase → Auth → URL Configuration: добавьте домен Vercel в Site URL.)

## Тест
1. Студент регистрируется, выбирает комнату, жмёт «Я сдал бельё» → 🟡.
2. Laundry входит → раскрывает студента → комплекты + фото → «Подтвердить».
3. Студент видит 🟢 и уведомление; Director видит статистику, этаж, студента и фото.
4. Проверка защиты: у студента нет прав на UPDATE/INSERT в `submissions` — только RPC `student_mark_submitted` (создаёт лишь `pending`).

## Безопасность
Ключей в коде нет. Используется только anon key; все записи идут через RLS и `security definer`-функции, подтверждение требует роль laundry/director, фото и число комплектов.
