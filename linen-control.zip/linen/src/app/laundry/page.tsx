import { me, currentPeriod, st } from "@/lib/data";
import { confirm, signOut } from "../actions";
export default async function Laundry() {
  const { s } = await me(["laundry", "director"]);
  const { cur } = await currentPeriod(s);
  if (!cur) return <main className="p-6">Нет активного периода.</main>;
  const { data: students } = await s.from("profiles").select("id, full_name, rooms(number)").eq("role", "student").not("room_id", "is", null);
  const { data: subs } = await s.from("submissions").select("student_id, status").eq("period_id", cur.id);
  const rank = (x: string | undefined) => (x === "pending" ? 0 : x === "confirmed" ? 2 : 1);
  const rows = (students ?? []).map((x: any) => ({ ...x, status: subs?.find((y) => y.student_id === x.id)?.status }))
    .sort((a: any, b: any) => rank(a.status) - rank(b.status) || a.rooms.number.localeCompare(b.rooms.number));
  return (
    <main className="mx-auto max-w-2xl space-y-3 p-4">
      <header className="flex justify-between"><h1 className="text-xl font-bold">Приём белья · {cur.name}</h1>
        <form action={signOut}><button className="text-sm text-gray-500 underline">Выйти</button></form></header>
      {rows.map((r: any) => { const x = st(r.status); return (
        <details key={r.id} className="rounded-2xl bg-white p-4 shadow-sm">
          <summary className="flex cursor-pointer justify-between"><span>{r.rooms.number} · {r.full_name}</span><span className={`rounded-full px-3 text-sm ${x.cls}`}>{x.icon} {x.label}</span></summary>
          {r.status !== "confirmed" && (
            <form action={confirm} className="mt-3 space-y-2">
              <input type="hidden" name="student" value={r.id} /><input type="hidden" name="period" value={cur.id} />
              <input name="sets" type="number" min={1} required placeholder="Комплектов" className="w-full rounded-xl border p-3" />
              <input name="received" type="datetime-local" className="w-full rounded-xl border p-3" />
              <input name="photo" type="file" accept="image/*" capture="environment" required className="w-full" />
              <button className="w-full rounded-xl bg-green-600 py-3 font-semibold text-white">Подтвердить</button>
            </form>)}
        </details>); })}
    </main>
  );
}
