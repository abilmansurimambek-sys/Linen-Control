import "./globals.css";
export const metadata = { title: "Постельное бельё — жатақхана" };
export default function L({ children }: { children: React.ReactNode }) {
  return <html lang="ru"><body className="bg-gray-50 text-gray-900 antialiased">{children}</body></html>;
}
