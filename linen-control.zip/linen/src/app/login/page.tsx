"use client";
import { useActionState, useState } from "react";
import { signIn, signUp } from "../actions";
export default function Login() {
  const [reg, setReg] = useState(false);
  const [state, act, pending] = useActionState(reg ? signUp : signIn, null as { error?: string } | null);
  const inp = "w-full rounded-xl border px-4 py-3 text-base";
  return (
    <main className="mx-auto max-w-sm p-6 pt-20">
      <h1 className="mb-6 text-2xl font-bold">Сдача белья</h1>
      <form action={act} className="space-y-3">
        {reg && <input name="full_name" placeholder="ФИО" required className={inp} />}
        <input name="email" type="email" placeholder="Email" required className={inp} />
        <input name="password" type="password" placeholder="Пароль (мин. 6)" required minLength={6} className={inp} />
        {state?.error && <p className="text-sm text-red-600">{state.error}</p>}
        <button disabled={pending} className="w-full rounded-xl bg-black py-3 font-semibold text-white">{reg ? "Регистрация" : "Войти"}</button>
      </form>
      <button onClick={() => setReg(!reg)} className="mt-4 text-sm text-gray-500 underline">{reg ? "Уже есть аккаунт" : "Я студент — зарегистрироваться"}</button>
    </main>
  );
}
