"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { sb } from "@/lib/supabase/server";

export async function signIn(_: unknown, f: FormData) {
  const s = await sb();
  const { error } = await s.auth.signInWithPassword({ email: String(f.get("email")), password: String(f.get("password")) });
  if (error) return { error: error.message };
  redirect("/");
}
export async function signUp(_: unknown, f: FormData) {
  const s = await sb();
  const { data, error } = await s.auth.signUp({ email: String(f.get("email")), password: String(f.get("password")),
    options: { data: { full_name: String(f.get("full_name") || "") } } });
  if (error) return { error: error.message };
  if (!data.session) return { error: "Проверьте почту для подтверждения (или отключите Confirm email в Supabase)." };
  redirect("/");
}
export async function signOut() { const s = await sb(); await s.auth.signOut(); redirect("/login"); }
export async function setRoom(f: FormData) {
  const s = await sb(); await s.rpc("set_my_room", { p_room: Number(f.get("room")) }); revalidatePath("/student");
}
export async function markSubmitted(f: FormData) {
  const s = await sb(); await s.rpc("student_mark_submitted", { p_period: Number(f.get("period")) }); revalidatePath("/student");
}
export async function confirm(f: FormData) {
  const s = await sb();
  const { data: { user } } = await s.auth.getUser();
  const file = f.get("photo") as File;
  const period = Number(f.get("period")), student = String(f.get("student"));
  if (!user || !file || file.size === 0) return;
  const path = `${period}/${student}-${Date.now()}.${(file.name.split(".").pop() || "jpg").toLowerCase()}`;
  const up = await s.storage.from("linen-photos").upload(path, file, { contentType: file.type });
  if (up.error) throw new Error(up.error.message);
  const rec = String(f.get("received") || "");
  const { error } = await s.rpc("confirm_submission", { p_student: student, p_period: period, p_sets: Number(f.get("sets")),
    p_photo: path, p_received: rec ? new Date(rec).toISOString() : null });
  if (error) throw new Error(error.message);
  revalidatePath("/laundry");
}
export async function createPeriod(f: FormData) {
  const s = await sb();
  await s.from("periods").insert({ name: String(f.get("name")), start_date: String(f.get("start")), end_date: String(f.get("end")) });
  revalidatePath("/admin");
}
