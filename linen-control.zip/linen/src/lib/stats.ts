export async function periodData(s: any, periodId: number) {
  const { data: students } = await s.from("profiles").select("id, full_name, rooms(number, floors(number))").eq("role", "student").not("room_id", "is", null);
  const { data: subs } = await s.from("submissions").select("*, laundry_confirmations(*)").eq("period_id", periodId);
  return (students ?? []).map((x: any) => ({ ...x, floor: x.rooms.floors.number, room: x.rooms.number, sub: subs?.find((y: any) => y.student_id === x.id) })) as any[];
}
export const pct = (rows: any[]) => (rows.length ? Math.round((rows.filter((r) => r.sub?.status === "confirmed").length / rows.length) * 1000) / 10 : 0);
